﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Data.OleDb;


namespace upload_excel_data_to_sql_server
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int rollno;
            String sname;
            String fname;
            String mname;
            string path = Path.GetFileName(FileUpload1.FileName);
            path = path.Replace(" ", "");
            FileUpload1.SaveAs(Server.MapPath("~/ExcelFile/") + path);
            String ExcelPath = Server.MapPath("~/ExcelFile/") + path;
            OleDbConnection mycon = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source = " + ExcelPath + "; Extended Properties=Excel 8.0; Persist Security Info = False");
            mycon.Open();
            OleDbCommand cmd = new OleDbCommand("select * from [Sheet1$]", mycon);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                // Response.Write("<br/>"+dr[0].ToString());
                rollno = Convert.ToInt32(dr[0].ToString());
                sname = dr[1].ToString();
                fname = dr[2].ToString();
                mname = dr[3].ToString();
                savedata(rollno, sname, fname, mname);


            }
            Label2.Text = "Data Has Been Saved Successfully";

        }
        private void savedata(int rollno1, String sname1, String fname1, String mname1)
        {
            String query = "insert into UXdata1(rollno,sname,fname,mname) values(" + rollno1 + ",'" + sname1 + "','" + fname1 + "','" + mname1 + "')";
            String mycon = "Data Source= CH0002\\SQLSERVER2012 ; Initial Catalog=emp; Integrated Security=true";
            SqlConnection con = new SqlConnection(mycon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = query;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

    }
}