﻿namespace upload_excel_data_to_sql_server
{
    internal class Date
    {
    }
}