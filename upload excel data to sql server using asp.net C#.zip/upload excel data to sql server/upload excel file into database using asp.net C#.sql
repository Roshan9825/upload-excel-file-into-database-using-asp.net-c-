use emp
create table UXdata1(
rollno int ,
sname varchar(150),
fname varchar(150),
mname varchar(150));
select *from UXdata1;